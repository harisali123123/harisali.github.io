# Haris Ali — Shopify Theme Editor Portfolio

A fast, mobile-responsive, single-file portfolio website. No frameworks, no build step, no external libraries.

**Live site:** `https://YOUR-USERNAME.github.io/YOUR-REPO-NAME/`
*(replace with your real link after publishing)*

## Files

| File | Purpose |
|------|---------|
| `index.html` | The entire website (HTML, CSS and JavaScript) |
| `README.md` | This file |

## Test locally

Double-click `index.html` to open it in Chrome or any browser.

## Publish on GitHub Pages

1. Create a new **public** repository on GitHub.
2. Click **Add file → Upload files**, drag in `index.html` and `README.md`, then click **Commit changes**.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
5. Choose branch **main** and folder **/ (root)**, then click **Save**.
6. Wait 1–3 minutes and refresh. Your site link appears at the top of the Pages settings.

> `index.html` must stay in the repository root (not inside a folder) and the file name must be lowercase.

## Contact

harisali278711@gmail.com
